package com.ayyanarsweets.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Purple = Color(0xFF4B0A63)
private val Purple2 = Color(0xFF6D1591)
private val Gold = Color(0xFFD4AF37)
private val Cream = Color(0xFFFFF9F0)

data class Product(
    val name: String,
    val price: Int,
    val pack: String,
    val category: String,
    val icon: String
)

val products = listOf(
    Product("Nice Peanut Chikki", 50, "50 pcs (Packet)", "Kadalai Mittai", "🥜"),
    Product("Peanut Chikki", 75, "75 pcs (Packet)", "Kadalai Mittai", "🥜"),
    Product("Ellu Chikki", 60, "50 pcs (Packet)", "Ellu Mittai", "⚫"),
    Product("Mysore Pak", 80, "250g Pack", "Mysore Pak", "🟨"),
    Product("Peanut Chikki Jar", 150, "50 pcs (Jar)", "Chikki", "🫙"),
    Product("Kamarkat", 60, "50 pcs", "Kamarkat", "🍬"),
    Product("Pineapple Purfi", 100, "250g Pack", "Purfi", "🍍")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AyyanarApp() }
    }
}

@Composable
fun AyyanarApp() {
    var selectedTab by remember { mutableStateOf(0) }
    var cart by remember { mutableStateOf(mapOf<String, Int>()) }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Purple,
            secondary = Gold,
            background = Cream
        )
    ) {
        Scaffold(
            bottomBar = {
                NavigationBar(containerColor = Purple) {
                    listOf(
                        Icons.Default.Home to "Home",
                        Icons.Default.ShoppingBag to "Products",
                        Icons.Default.ShoppingCart to "Cart",
                        Icons.Default.Receipt to "Orders",
                        Icons.Default.Menu to "More"
                    ).forEachIndexed { index, pair ->
                        NavigationBarItem(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            icon = { Icon(pair.first, contentDescription = pair.second) },
                            label = { Text(pair.second) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Gold,
                                selectedTextColor = Color.White,
                                unselectedIconColor = Color.White,
                                unselectedTextColor = Color.White
                            )
                        )
                    }
                }
            }
        ) { padding ->
            when (selectedTab) {
                0 -> HomeScreen(padding) { selectedTab = 1 }
                1 -> ProductsScreen(padding, cart) { p ->
                    cart = cart.toMutableMap().apply { this[p.name] = (this[p.name] ?: 0) + 1 }
                }
                2 -> CartScreen(padding, cart, products) { name ->
                    cart = cart.toMutableMap().apply {
                        val n = (this[name] ?: 0) - 1
                        if (n <= 0) remove(name) else this[name] = n
                    }
                }
                3 -> OrdersScreen(padding)
                else -> MoreScreen(padding)
            }
        }
    }
}

@Composable
fun Header(title: String) {
    Surface(color = Purple, modifier = Modifier.fillMaxWidth()) {
        Row(
            Modifier.padding(18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "AYYANAR\nSWEETS",
                color = Gold,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                lineHeight = 18.sp
            )
            Spacer(Modifier.width(18.dp))
            Text(title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun HomeScreen(padding: PaddingValues, shop: () -> Unit) {
    LazyColumn(
        modifier = Modifier.padding(padding).fillMaxSize().background(Cream),
        contentPadding = PaddingValues(bottom = 16.dp)
    ) {
        item {
            Header("Home")
            Spacer(Modifier.height(12.dp))
            Card(
                Modifier.padding(16.dp).fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Purple),
                shape = RoundedCornerShape(22.dp)
            ) {
                Column(Modifier.padding(22.dp)) {
                    Text("Pure Ingredients", color = Gold, fontSize = 16.sp)
                    Text("Traditional Taste", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    Text("Premium Quality", color = Color.White, fontSize = 17.sp)
                    Spacer(Modifier.height(14.dp))
                    Button(
                        onClick = shop,
                        colors = ButtonDefaults.buttonColors(containerColor = Gold)
                    ) { Text("Shop Now →", color = Purple, fontWeight = FontWeight.Bold) }
                }
            }
        }
        item {
            Text("Our Best Sellers", Modifier.padding(horizontal = 16.dp), fontWeight = FontWeight.Bold, fontSize = 20.sp)
            Spacer(Modifier.height(8.dp))
        }
        items(products.take(3)) { ProductCard(it) {} }
    }
}

@Composable
fun ProductsScreen(padding: PaddingValues, cart: Map<String, Int>, add: (Product) -> Unit) {
    Column(Modifier.padding(padding).fillMaxSize().background(Cream)) {
        Header("Products")
        TextField(
            value = "",
            onValueChange = {},
            placeholder = { Text("Search for sweets...") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            modifier = Modifier.padding(12.dp).fillMaxWidth(),
            singleLine = true,
            shape = RoundedCornerShape(25.dp)
        )
        LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
            items(products) { p ->
                ProductCard(p) { add(p) }
            }
        }
    }
}

@Composable
fun ProductCard(p: Product, add: () -> Unit) {
    Card(
        Modifier.padding(horizontal = 12.dp, vertical = 6.dp).fillMaxWidth(),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(72.dp).background(Color(0xFFFFE8D0), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) { Text(p.icon, fontSize = 34.sp) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(p.name, fontWeight = FontWeight.Bold)
                Text("₹${p.price}", color = Purple2, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(p.pack, fontSize = 12.sp, color = Color.Gray)
            }
            Button(
                onClick = add,
                colors = ButtonDefaults.buttonColors(containerColor = Purple2),
                shape = RoundedCornerShape(10.dp)
            ) { Text("Add") }
        }
    }
}

@Composable
fun CartScreen(padding: PaddingValues, cart: Map<String, Int>, all: List<Product>, removeOne: (String) -> Unit) {
    val total = cart.entries.sumOf { (name, qty) ->
        (all.find { it.name == name }?.price ?: 0) * qty
    }
    Column(Modifier.padding(padding).fillMaxSize().background(Cream)) {
        Header("My Cart")
        if (cart.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Your cart is empty", fontSize = 20.sp)
            }
        } else {
            LazyColumn(Modifier.weight(1f)) {
                items(cart.entries.toList()) { entry ->
                    val p = all.find { it.name == entry.key } ?: return@items
                    Row(
                        Modifier.fillMaxWidth().padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(p.icon, fontSize = 30.sp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(p.name, fontWeight = FontWeight.Bold)
                            Text("₹${p.price} × ${entry.value}")
                        }
                        Text("₹${p.price * entry.value}", fontWeight = FontWeight.Bold)
                        IconButton(onClick = { removeOne(entry.key) }) {
                            Icon(Icons.Default.Delete, null)
                        }
                    }
                }
            }
            Surface(color = Color.White, shadowElevation = 8.dp) {
                Column(Modifier.padding(18.dp)) {
                    Text("Subtotal: ₹$total", fontSize = 18.sp)
                    Text("Delivery: ₹30", fontSize = 15.sp)
                    Text("Total: ₹${total + 30}", fontSize = 23.sp, fontWeight = FontWeight.Bold)
                    Button(
                        onClick = {},
                        modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Purple)
                    ) { Text("Proceed to Checkout") }
                }
            }
        }
    }
}

@Composable
fun OrdersScreen(padding: PaddingValues) {
    Column(Modifier.padding(padding).fillMaxSize().background(Cream)) {
        Header("Orders")
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No orders yet", fontSize = 20.sp)
        }
    }
}

@Composable
fun MoreScreen(padding: PaddingValues) {
    Column(Modifier.padding(padding).fillMaxSize().background(Purple)) {
        Header("More")
        listOf(
            "👤  My Profile",
            "📍  My Address",
            "🎁  Offers & Notifications",
            "📞  Contact Us",
            "ℹ️  About Ayyanar Sweets",
            "⚙️  Settings"
        ).forEach {
            Text(
                it,
                Modifier.fillMaxWidth().clickable {}.padding(20.dp),
                color = Color.White,
                fontSize = 17.sp
            )
        }
        Spacer(Modifier.weight(1f))
        Text("Traditional in Every Bite", color = Gold, modifier = Modifier.align(Alignment.CenterHorizontally).padding(25.dp))
    }
}
